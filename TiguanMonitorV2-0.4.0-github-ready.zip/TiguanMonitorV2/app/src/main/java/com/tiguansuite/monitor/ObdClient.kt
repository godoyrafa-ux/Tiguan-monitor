package com.tiguansuite.monitor

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale

/** Serialized, thread-safe, read-only ELM327 TCP client. No Mode 04 clear-DTC or write commands. */
class ObdClient {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private val ioMutex = Mutex()

    suspend fun connect(host: String, port: Int): String = ioMutex.withLock {
        withContext(Dispatchers.IO) {
            closeInternal()
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host.trim(), port), 5000)
            s.soTimeout = 3000
            socket = s
            input = s.getInputStream()
            output = s.getOutputStream()
            val banner = readPrompt(2500)
            // Safe read-only initialization sequence
            listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0", "ATAT1").forEach { cmd ->
                val wait = if (cmd == "ATZ") 2500 else 1500
                sendInternal(cmd, wait)
            }
            val cleanBanner = banner.replace(Regex("[^\x20-\x7E]"), "").trim()
            if (cleanBanner.isNotEmpty()) "ELM pronto (${cleanBanner.take(28)})" else "ELM327 conectado"
        }
    }

    suspend fun command(cmd: String, timeoutMs: Int = 2200): String = ioMutex.withLock {
        withContext(Dispatchers.IO) {
            val normalized = cmd.replace(" ", "").uppercase(Locale.US)
            val isAllowedObd = normalized.matches(Regex("^(01|03|06|07|09|0A)[0-9A-F]{0,4}$"))
            val isAllowedAt = normalized in setOf("ATRV", "ATDP", "ATDPN", "ATI", "AT@1")
            require(isAllowedObd || isAllowedAt) { "Comando não permitido (somente leitura): $normalized" }
            sendInternal(normalized, timeoutMs)
        }
    }

    private fun sendInternal(cmd: String, timeoutMs: Int): String {
        val out = output ?: error("Sem conexão")
        socket?.soTimeout = timeoutMs
        out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
        out.flush()
        return readPrompt(timeoutMs)
    }

    private fun readPrompt(timeoutMs: Int): String {
        val ins = input ?: error("Sem conexão")
        socket?.soTimeout = timeoutMs
        val b = StringBuilder()
        while (b.length < 4096) {
            val c = ins.read()
            if (c < 0) break
            if (c.toChar() == '>') break
            b.append(c.toChar())
        }
        return b.toString().replace("\r", " ").replace("\n", " ").trim()
    }

    private fun closeInternal() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        input = null
        output = null
    }

    fun close() {
        closeInternal()
    }
}

object Obd {
    fun hexBytes(raw: String): List<Int> {
        val s = raw.uppercase(Locale.US)
            .replace(Regex("\\b(NO DATA|SEARCHING\\.*|STOPPED|UNABLE TO CONNECT|BUS INIT:?\\s*ERROR|OK|ELM327\\s*V[0-9.]+)\\b"), "")
        val clean = s.replace(Regex("[^0-9A-F]"), "")
        if (clean.length < 4 || clean.length % 2 != 0) return emptyList()
        return clean.chunked(2).mapNotNull { it.toIntOrNull(16) }
    }

    private fun payload(raw: String, service: Int): List<Int> {
        val b = hexBytes(raw)
        val i = b.indexOf(service)
        return if (i >= 0) b.drop(i + 1) else emptyList()
    }

    fun pid(raw: String, pid: Int): List<Int> {
        val b = hexBytes(raw)
        val i = b.indices.firstOrNull { it + 1 < b.size && b[it] == 0x41 && b[it + 1] == pid } ?: return emptyList()
        return b.drop(i + 2)
    }

    fun supportedPids(raw: String, basePid: Int): Set<Int> {
        val data = pid(raw, basePid)
        if (data.size < 4) return emptySet()
        val mask = (data[0].toLong() shl 24) or
            (data[1].toLong() shl 16) or
            (data[2].toLong() shl 8) or
            data[3].toLong()
        val supported = mutableSetOf<Int>()
        for (bit in 0 until 32) {
            if (((mask shr (31 - bit)) and 1L) == 1L) {
                supported.add(basePid + bit + 1)
            }
        }
        return supported
    }

    fun load(r: String): Double? = pid(r, 0x04).firstOrNull()?.let { it * 100.0 / 255.0 }
    fun temp(r: String, p: Int): Int? = pid(r, p).firstOrNull()?.minus(40)
    fun trim(r: String, p: Int): Double? = pid(r, p).firstOrNull()?.let { (it - 128) * 100.0 / 128.0 }
    fun map(r: String): Int? = pid(r, 0x0B).firstOrNull()
    fun rpm(r: String): Double? = pid(r, 0x0C).takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 4.0 }
    fun speed(r: String): Int? = pid(r, 0x0D).firstOrNull()
    fun timingAdvance(r: String): Double? = pid(r, 0x0E).firstOrNull()?.let { (it / 2.0) - 64.0 }
    fun throttle(r: String): Double? = pid(r, 0x11).firstOrNull()?.let { it * 100.0 / 255.0 }
    fun fuelRailGaugeKpa(r: String): Int? = pid(r, 0x23).takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) * 10 }
    fun baro(r: String): Int? = pid(r, 0x33).firstOrNull()

    fun voltage(r: String): Double? =
        Regex("([0-9]+(?:\\.[0-9]+)?)\\s*V", RegexOption.IGNORE_CASE)
            .find(r)?.groupValues?.get(1)?.toDoubleOrNull()

    fun dtcs(raw: String, service: Int): List<String> {
        val b = payload(raw, service)
        val out = mutableListOf<String>()
        for (i in b.indices step 2) {
            if (i + 1 >= b.size) break
            val a = b[i]
            val c = b[i + 1]
            if (a == 0 && c == 0) continue
            val prefix = when ((a shr 6) and 3) {
                0 -> "P"
                1 -> "C"
                2 -> "B"
                else -> "U"
            }
            val n = ((a and 0x3F) shl 8) or c
            out += prefix + "%04X".format(n)
        }
        return out.distinct()
    }

    /** Mode 06 data is kept raw: TID/CID interpretation is ECU/protocol dependent. */
    fun mode06(raw: String): List<String> {
        val b = payload(raw, 0x46)
        if (b.isEmpty()) return emptyList()
        return b.chunked(8).filter { it.size == 8 }.map {
            val valRaw = it[2] * 256 + it[3]
            val minRaw = it[4] * 256 + it[5]
            val maxRaw = it[6] * 256 + it[7]
            "TID %02X · CID %02X · val %d · min %d · max %d".format(it[0], it[1], valRaw, minRaw, maxRaw)
        }
    }
}
