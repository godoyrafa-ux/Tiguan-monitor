package com.tiguansuite.monitor

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF080B0F)
private val Panel = Color(0xFF151A20)
private val PanelBorder = Color(0xFF232B35)
private val Red = Color(0xFFE32636)
private val Green = Color(0xFF35D06F)
private val Amber = Color(0xFFFFC247)
private val Cyan = Color(0xFF38BDF8)
private val Muted = Color(0xFF9AA4AF)

data class Reading(
    val rpm: Double? = null,
    val speed: Int? = null,
    val coolant: Int? = null,
    val map: Int? = null,
    val baro: Int? = null,
    val iat: Int? = null,
    val stft: Double? = null,
    val ltft: Double? = null,
    val load: Double? = null,
    val throttle: Double? = null,
    val timing: Double? = null,
    val fuelRailKpa: Int? = null,
    val volts: Double? = null
) {
    val boostBar: Double?
        get() = if (map != null) {
            val atm = baro ?: 101
            (map - atm) / 100.0
        } else null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyFullscreen()
        setContent { App() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen()
    }

    private fun applyFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
        }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tiguan_monitor_prefs", Context.MODE_PRIVATE) }

    var host by remember { mutableStateOf(prefs.getString("host", "192.168.0.10") ?: "192.168.0.10") }
    var portText by remember { mutableStateOf(prefs.getInt("port", 35000).toString()) }
    var pollIntervalMs by remember { mutableLongStateOf(prefs.getLong("poll_ms", 800L)) }

    val scope = rememberCoroutineScope()
    val client = remember { ObdClient() }

    var connected by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Conecte-se à rede Wi-Fi do ELM327") }
    var tab by remember { mutableIntStateOf(0) }
    var reading by remember { mutableStateOf(Reading()) }
    var supportedPids by remember { mutableStateOf(emptySet<Int>()) }

    var codes by remember { mutableStateOf(listOf<String>()) }
    var pending by remember { mutableStateOf(listOf<String>()) }
    var permanent by remember { mutableStateOf(listOf<String>()) }
    var tests by remember { mutableStateOf(listOf<String>()) }

    var lastUpdate by remember { mutableStateOf("--:--:--") }
    var failures by remember { mutableIntStateOf(0) }
    var polling by remember { mutableStateOf(false) }
    val history = remember { mutableStateListOf<Reading>() }

    DisposableEffect(Unit) {
        onDispose {
            polling = false
            client.close()
        }
    }

    fun saveSettings(newHost: String, newPortStr: String, newPollMs: Long) {
        val cleanHost = newHost.trim().ifEmpty { "192.168.0.10" }
        val cleanPort = newPortStr.trim().toIntOrNull()?.coerceIn(1, 65535) ?: 35000
        host = cleanHost
        portText = cleanPort.toString()
        pollIntervalMs = newPollMs
        prefs.edit()
            .putString("host", cleanHost)
            .putInt("port", cleanPort)
            .putLong("poll_ms", newPollMs)
            .apply()
    }

    fun disconnect() {
        polling = false
        connected = false
        client.close()
        status = "Desconectado"
    }

    suspend fun discoverPids(): Set<Int> {
        val found = mutableSetOf<Int>()
        runCatching { found += Obd.supportedPids(client.command("0100", 2500), 0x00) }
        if (0x20 in found) {
            runCatching { found += Obd.supportedPids(client.command("0120", 2500), 0x20) }
        }
        if (0x40 in found) {
            runCatching { found += Obd.supportedPids(client.command("0140", 2500), 0x40) }
        }
        return found
    }

    suspend fun pollLoop() {
        polling = true
        var tick = 0
        var cachedBaro: Int? = null
        while (polling && kotlinx.coroutines.currentCoroutineContext().isActive) {
            try {
                val rpm = Obd.rpm(client.command("010C"))
                val speed = Obd.speed(client.command("010D"))
                val mapVal = Obd.map(client.command("010B"))
                val coolant = Obd.temp(client.command("0105"), 0x05)

                // Secondary sensors read every 2nd cycle to keep RPM/MAP refresh fast
                val iat = if (tick % 2 == 0) Obd.temp(client.command("010F"), 0x0F) else reading.iat
                val stft = if (tick % 2 == 0) Obd.trim(client.command("0106"), 0x06) else reading.stft
                val ltft = if (tick % 4 == 0) Obd.trim(client.command("0107"), 0x07) else reading.ltft
                val load = if (tick % 2 == 1) Obd.load(client.command("0104")) else reading.load
                val throttle = if (tick % 2 == 1) Obd.throttle(client.command("0111")) else reading.throttle
                val timing = if (tick % 2 == 1) Obd.timingAdvance(client.command("010E")) else reading.timing

                val fuelRail = if (0x23 in supportedPids && tick % 2 == 1) {
                    Obd.fuelRailGaugeKpa(client.command("0123"))
                } else reading.fuelRailKpa

                if ((0x33 in supportedPids) && (cachedBaro == null || tick % 30 == 0)) {
                    cachedBaro = Obd.baro(client.command("0133")) ?: cachedBaro
                }

                val volts = if (tick % 3 == 0) Obd.voltage(client.command("ATRV")) else reading.volts

                val r = Reading(
                    rpm = rpm,
                    speed = speed,
                    coolant = coolant,
                    map = mapVal,
                    baro = cachedBaro,
                    iat = iat,
                    stft = stft,
                    ltft = ltft,
                    load = load,
                    throttle = throttle,
                    timing = timing,
                    fuelRailKpa = fuelRail,
                    volts = volts
                )
                reading = r
                history.add(r)
                if (history.size > 150) history.removeAt(0)

                failures = 0
                tick++
                status = "Dados atualizados · ${supportedPids.size} PIDs detectados"
                lastUpdate = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            } catch (e: Exception) {
                failures++
                status = "Falha leitura ($failures/4): ${e.message}"
                if (failures >= 4) {
                    disconnect()
                    break
                }
            }
            delay(pollIntervalMs)
        }
    }

    suspend fun scanDiagnostics(includeMode06: Boolean) {
        if (scanning) return
        scanning = true
        status = "Executando varredura OBD (somente leitura)..."
        try {
            codes = Obd.dtcs(client.command("03", 3000), 0x43)
            pending = Obd.dtcs(client.command("07", 3000), 0x47)
            permanent = Obd.dtcs(client.command("0A", 3000), 0x4A)
            if (includeMode06) {
                tests = Obd.mode06(client.command("0600", 4500))
            }
            status = "Varredura concluída"
        } catch (e: Exception) {
            status = "Erro na varredura: ${e.message}"
        } finally {
            scanning = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Header(
                connected = connected,
                busy = busy,
                status = status,
                onConnect = {
                    busy = true
                    val port = portText.toIntOrNull() ?: 35000
                    scope.launch {
                        try {
                            status = "Conectando a $host:$port..."
                            val msg = client.connect(host, port)
                            status = "$msg · Mapeando PIDs..."
                            supportedPids = discoverPids()
                            connected = true
                            busy = false
                            pollLoop()
                        } catch (e: Exception) {
                            status = "Conexão falhou: ${e.message}"
                            busy = false
                            client.close()
                        }
                    }
                },
                onDisconnect = { disconnect() }
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> Dashboard(reading, connected, lastUpdate)
                    1 -> EngineScreen(reading, supportedPids)
                    2 -> MisfireScreen(connected, scanning, tests) { scope.launch { scanDiagnostics(includeMode06 = true) } }
                    3 -> DiagnosticScreen(connected, scanning, codes, pending, permanent) { scope.launch { scanDiagnostics(includeMode06 = false) } }
                    4 -> ChartsScreen(history.toList())
                    else -> SettingsScreen(
                        host = host,
                        portText = portText,
                        pollIntervalMs = pollIntervalMs,
                        connected = connected,
                        supportedCount = supportedPids.size,
                        lastUpdate = lastUpdate,
                        status = status,
                        onSave = ::saveSettings
                    )
                }
            }

            Navigation(tab) { tab = it }
            Text(
                "TIGUAN 5N · EA888 CCTA · JVZ 09M · SOMENTE LEITURA · v0.4.0",
                color = Muted,
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
fun Header(connected: Boolean, busy: Boolean, status: String, onConnect: () -> Unit, onDisconnect: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF10151B), RoundedCornerShape(12.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .size(32.dp)
                    .border(1.5.dp, Color.LightGray, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("VW", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Column {
                Text("Tiguan Monitor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("2.0 TSI CCTA · 4Motion · 2011", color = Muted, fontSize = 11.sp)
            }
        }

        Text(
            status,
            color = if (connected) Green else Muted,
            fontSize = 11.sp,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(8.dp).background(if (connected) Green else Amber, CircleShape))
            Text(if (connected) "OBD Wi-Fi" else "OFFLINE", color = if (connected) Green else Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            if (!connected) {
                Button(
                    enabled = !busy,
                    onClick = onConnect,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(if (busy) "CONECTANDO..." else "CONECTAR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = onDisconnect,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("PARAR", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun Navigation(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("Painel", "Motor", "Misfire", "Diagnóstico", "Gráficos", "Config.")
    val icons = listOf("⌂", "◉", "ϟ", "▣", "⌁", "⚙")
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(12.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(12.dp))
            .padding(3.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        labels.forEachIndexed { i, label ->
            Column(
                Modifier
                    .weight(1f)
                    .clickable { onSelect(i) }
                    .background(if (selected == i) Color(0xFF35151A) else Color.Transparent, RoundedCornerShape(8.dp))
                    .padding(vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(icons[i], color = if (selected == i) Red else Muted, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    label,
                    color = if (selected == i) Color.White else Muted,
                    fontSize = 10.sp,
                    fontWeight = if (selected == i) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun Dashboard(r: Reading, connected: Boolean, updated: String) {
    val coolantColor = when {
        r.coolant == null -> Color.White
        r.coolant >= 106 -> Red
        r.coolant >= 101 -> Amber
        else -> Color.White
    }
    val iatColor = when {
        r.iat == null -> Color.White
        r.iat >= 55 -> Amber
        else -> Color.White
    }
    val voltColor = when {
        r.volts == null -> Color.White
        (r.rpm ?: 0.0) > 600 && r.volts < 13.2 -> Amber
        r.volts < 11.8 -> Red
        else -> Green
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.weight(1.18f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Gauge(
                label = "ROTAÇÃO",
                value = r.rpm?.let { "%.0f".format(it) } ?: "--",
                unit = "RPM",
                fraction = if (r.rpm != null) (r.rpm / 7000.0).toFloat() else 0f,
                accent = if ((r.rpm ?: 0.0) >= 6200) Amber else Red,
                modifier = Modifier.weight(1f)
            )
            Gauge(
                label = "VELOCIDADE",
                value = r.speed?.toString() ?: "--",
                unit = "km/h",
                fraction = if (r.speed != null) (r.speed / 220f) else 0f,
                accent = Cyan,
                modifier = Modifier.weight(1f)
            )
        }

        Row(Modifier.weight(0.70f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("TEMP. LÍQUIDO", r.coolant?.toString(), "°C", Modifier.weight(1f), valueColor = coolantColor)
            Metric("TEMP. ADMISSÃO", r.iat?.toString(), "°C", Modifier.weight(1f), valueColor = iatColor)
            val mapDisplay = if (r.map != null && r.boostBar != null) {
                "${r.map} (${"%+.2f".format(r.boostBar)} bar)"
            } else r.map?.toString()
            Metric("PRESSÃO MAP / BOOST", mapDisplay, "kPa abs", Modifier.weight(1f))
        }

        Row(Modifier.weight(0.70f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("STFT", r.stft?.let { "%+.1f".format(it) }, "%", Modifier.weight(1f))
            Metric("LTFT", r.ltft?.let { "%+.1f".format(it) }, "%", Modifier.weight(1f))
            Metric("TENSÃO BATERIA", r.volts?.let { "%.1f".format(it) }, "V", Modifier.weight(1f), valueColor = voltColor)
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(10.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("STATUS DO VEÍCULO:", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (connected) "ECU conectada · Leitura ativa" else "Aguardando conexão Wi-Fi ELM327",
                    color = if (connected) Green else Amber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text("Atualizado $updated", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun EngineScreen(r: Reading, supportedPids: Set<Int>) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MOTOR · EA888 2.0 TSI (CCTA)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("PIDs suportados mapeados: ${supportedPids.size}", color = Cyan, fontSize = 11.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("ROTAÇÃO", r.rpm?.let { "%.0f".format(it) }, "rpm", Modifier.weight(1f))
                Metric("CARGA CALCULADA", r.load?.let { "%.1f".format(it) }, "%", Modifier.weight(1f))
                Metric("STFT (CURTO PRAZO)", r.stft?.let { "%+.1f".format(it) }, "%", Modifier.weight(1f))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("PRESSÃO COLETOR (MAP)", r.map?.toString(), "kPa absolutos", Modifier.weight(1f))
                Metric("POSIÇÃO BORBOLETA", r.throttle?.let { "%.1f".format(it) }, "%", Modifier.weight(1f))
                Metric("LTFT (LONGO PRAZO)", r.ltft?.let { "%+.1f".format(it) }, "%", Modifier.weight(1f))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("AVANÇO IGNIÇÃO", r.timing?.let { "%+.1f".format(it) }, "° APMS", Modifier.weight(1f))
                Metric("PRESSÃO RAIL (FRP)", r.fuelRailKpa?.let { "%.1f".format(it / 100.0) }, "bar (PID 23)", Modifier.weight(1f))
                Metric("PRESSÃO BAROMÉTRICA", r.baro?.toString(), "kPa (PID 33)", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun MisfireScreen(connected: Boolean, scanning: Boolean, tests: List<String>, onRead: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MISFIRE · MONITOR DE COMBUSTÃO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(enabled = connected && !scanning, onClick = onRead) {
                Text(if (scanning) "LENDO..." else "CONSULTAR MODE 06", fontSize = 11.sp)
            }
        }

        CardPanel(Modifier.fillMaxWidth()) {
            Text("CONTADORES POR CILINDRO (1–4)", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Não disponíveis via OBD-II genérico (ELM327)", color = Amber, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                "Não exibimos zeros fictícios. O mapeamento por cilindro no EA888 CCTA exige protocolo VAG específico (UDS/TP2.0). Abaixo são exibidos os registros brutos TID/CID do Mode 06.",
                color = Muted,
                fontSize = 11.sp
            )
        }

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (tests.isEmpty()) {
                item {
                    CardPanel(Modifier.fillMaxWidth()) {
                        Text("Nenhum resultado Mode 06 retornado nesta sessão. Conecte e toque em CONSULTAR MODE 06.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            items(tests) { line ->
                CardPanel(Modifier.fillMaxWidth()) {
                    Text(line, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun DiagnosticScreen(
    connected: Boolean,
    scanning: Boolean,
    codes: List<String>,
    pending: List<String>,
    permanent: List<String>,
    onScan: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("DIAGNÓSTICO · CÓDIGOS DE FALHA (DTC)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Button(enabled = connected && !scanning, onClick = onScan) {
                Text(if (scanning) "LENDO..." else "LER CÓDIGOS (03 / 07 / 0A)", fontSize = 11.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CodePanel("CONFIRMADAS (MODE 03)", codes)
                CodePanel("PENDENTES (MODE 07)", pending)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CodePanel("PERMANENTES (MODE 0A)", permanent)
                CardPanel(Modifier.fillMaxWidth().weight(1f)) {
                    Text("SEGURANÇA DE LEITURA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Operação 100% passiva (somente leitura). O comando Mode 04 (apagar falhas) está bloqueado no código do cliente OBD.",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun ChartsScreen(history: List<Reading>) {
    var selectedMetric by remember { mutableIntStateOf(0) }
    val options = listOf("RPM", "MAP (kPa)", "Temp. Líquido (°C)", "STFT (%)", "Avanço Ignição (°)")

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("GRÁFICOS EM TEMPO REAL", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                options.forEachIndexed { idx, label ->
                    FilterChip(
                        selected = selectedMetric == idx,
                        onClick = { selectedMetric = idx },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
        }

        when (selectedMetric) {
            0 -> ChartCard("ROTAÇÃO DO MOTOR (RPM)", history.mapNotNull { it.rpm }, Red, 0.0, 7000.0, "%.0f", Modifier.weight(1f))
            1 -> ChartCard("PRESSÃO ABSOLUTA NO COLETOR · MAP (kPa)", history.mapNotNull { it.map?.toDouble() }, Cyan, 20.0, 250.0, "%.0f", Modifier.weight(1f))
            2 -> ChartCard("TEMPERATURA DO LÍQUIDO DE ARREFECIMENTO (°C)", history.mapNotNull { it.coolant?.toDouble() }, Green, 40.0, 120.0, "%.0f", Modifier.weight(1f))
            3 -> ChartCard("SHORT TERM FUEL TRIM · STFT (%)", history.mapNotNull { it.stft }, Amber, -25.0, 25.0, "%+.1f", Modifier.weight(1f))
            else -> ChartCard("AVANÇO DE IGNIÇÃO (° APMS)", history.mapNotNull { it.timing }, Cyan, -15.0, 45.0, "%+.1f", Modifier.weight(1f))
        }
    }
}

@Composable
fun SettingsScreen(
    host: String,
    portText: String,
    pollIntervalMs: Long,
    connected: Boolean,
    supportedCount: Int,
    lastUpdate: String,
    status: String,
    onSave: (String, String, Long) -> Unit
) {
    var editHost by remember(host) { mutableStateOf(host) }
    var editPort by remember(portText) { mutableStateOf(portText) }
    var editPoll by remember(pollIntervalMs) { mutableLongStateOf(pollIntervalMs) }
    var savedBanner by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("CONFIGURAÇÕES · ADAPTADOR & VEÍCULO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            CardPanel(Modifier.weight(1.2f)) {
                Text("CONEXÃO ELM327 WI-FI TCP", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = editHost,
                        onValueChange = { editHost = it; savedBanner = false },
                        label = { Text("IP do ELM327", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1.5f)
                    )
                    OutlinedTextField(
                        value = editPort,
                        onValueChange = { editPort = it; savedBanner = false },
                        label = { Text("Porta", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text("INTERVALO DE LEITURA (POLLING)", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(500L to "500 ms", 800L to "800 ms", 1200L to "1.2 s").forEach { (ms, label) ->
                        FilterChip(
                            selected = editPoll == ms,
                            onClick = { editPoll = ms; savedBanner = false },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        enabled = !connected,
                        onClick = {
                            onSave(editHost, editPort, editPoll)
                            savedBanner = true
                        }
                    ) {
                        Text("SALVAR", fontSize = 11.sp)
                    }
                }
                if (connected) {
                    Text("Desconecte para alterar IP/Porta.", color = Amber, fontSize = 10.sp)
                } else if (savedBanner) {
                    Text("Configurações salvas com sucesso.", color = Green, fontSize = 10.sp)
                }
            }

            CardPanel(Modifier.weight(1f)) {
                Text("PERFIL DO VEÍCULO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Volkswagen Tiguan 5N (2011)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Motor: 2.0 TSI EA888 Gen1 (CCTA)", color = Muted, fontSize = 12.sp)
                Text("Câmbio: Automático 6M Aisin 09M (JVZ) · 4Motion", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("PIDs detectados na ECU: $supportedCount", color = Cyan, fontSize = 11.sp)
                Text("Última leitura: $lastUpdate", color = Muted, fontSize = 11.sp)
                Text("Status: $status", color = Muted, fontSize = 11.sp, maxLines = 2)
            }
        }
    }
}

@Composable
fun Gauge(label: String, value: String, unit: String, fraction: Float, accent: Color = Red, modifier: Modifier = Modifier) {
    CardPanel(modifier) {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(6.dp)) {
                val stroke = 15.dp.toPx()
                val diameter = size.minDimension - stroke
                val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
                val arcSize = Size(diameter, diameter)
                drawArc(Color(0xFF28303A), 135f, 270f, false, topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                if (fraction > 0f) {
                    drawArc(accent, 135f, 270f * fraction.coerceIn(0f, 1f), false, topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(value, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(unit, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun Metric(label: String, value: String?, unit: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    CardPanel(modifier) {
        Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(value ?: "--", color = valueColor, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(unit, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun CardPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .background(Panel, RoundedCornerShape(12.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(12.dp))
            .padding(11.dp),
        verticalArrangement = Arrangement.Center,
        content = content
    )
}

@Composable
fun CodePanel(title: String, items: List<String>) {
    CardPanel(Modifier.fillMaxWidth().weight(1f)) {
        Text("$title (${items.size})", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        if (items.isEmpty()) {
            Text("Nenhum código reportado ou aguardando leitura", color = Muted, fontSize = 12.sp)
        } else {
            items.forEach { Text(it, color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun ChartCard(title: String, values: List<Double>, color: Color, min: Double, max: Double, fmt: String, modifier: Modifier) {
    val current = values.lastOrNull()
    val minVal = values.minOrNull()
    val maxVal = values.maxOrNull()

    CardPanel(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ATUAL: ${current?.let { fmt.format(it) } ?: "--"}", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("MÍN: ${minVal?.let { fmt.format(it) } ?: "--"}", color = Muted, fontSize = 11.sp)
                Text("MÁX: ${maxVal?.let { fmt.format(it) } ?: "--"}", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0..4) {
                val y = size.height * i / 4
                drawLine(Color(0xFF28303A), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
            }
            if (values.size > 1) {
                val pts = values.takeLast(120)
                val path = Path()
                pts.forEachIndexed { idx, v ->
                    val x = size.width * idx / (pts.size - 1)
                    val norm = ((v - min) / (max - min)).toFloat().coerceIn(0f, 1f)
                    val y = size.height - (norm * size.height)
                    if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, color = color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
            }
        }
    }
}
